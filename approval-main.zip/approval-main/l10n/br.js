OC.L10N.register(
    "approval",
    {
    "Cancel" : "Nullañ",
    "Create" : "Krouiñ",
    "Approve" : "Aotreañ",
    "Reject" : "Nac'hañ",
    "No result." : "Disoc'h ebet.",
    "Warning" : "Kemenadenn"
},
"nplurals=5; plural=((n%10 == 1) && (n%100 != 11) && (n%100 !=71) && (n%100 !=91) ? 0 :(n%10 == 2) && (n%100 != 12) && (n%100 !=72) && (n%100 !=92) ? 1 :(n%10 ==3 || n%10==4 || n%10==9) && (n%100 < 10 || n% 100 > 19) && (n%100 < 70 || n%100 > 79) && (n%100 < 90 || n%100 > 99) ? 2 :(n != 0 && n % 1000000 == 0) ? 3 : 4);");
